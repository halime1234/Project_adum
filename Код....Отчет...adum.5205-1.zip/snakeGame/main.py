import pygame
import sys
import random

# Инициализация Pygame
pygame.init()

# Настройки экрана
screen_width = 1000
screen_height = 720
screen = pygame.display.set_mode((screen_width, screen_height))

game_area_width = 920
game_area_height = 640

# Настройки шрифта
font = pygame.font.SysFont('Arial Black', 20)
font2 = pygame.font.SysFont(None, 45)

# Настройка цветов и шрифтов
black = (0, 0, 0)
white = (255, 255, 255)
red = (255, 0, 0)
blue = (0, 0, 255)
yellow = (255, 255, 0)

# Отступы игровой зоны от краев экрана
offset_x = (screen_width - game_area_width) // 2
offset_y = (screen_height - game_area_height) // 2

# Инициализируем список с уже существующими координатами
deadly_obstacles = [
    # 1
    # Добавляем горизонтальные препятствия
    (100, 100), (120, 100), (140, 100), (160, 100), (180, 100), (200, 100),
    (220, 100), (240, 100), (260, 100), (280, 100), (300, 100),
    # Добавляем вертикальные препятствия
    (100, 120), (100, 140), (100, 160), (100, 180), (100, 200),
    (100, 220), (100, 240),
    # 1

    # кубики 12
    (100, 300), (100, 340), (100, 360), (100, 400),

    # 2
    # Добавляем горизонтальные препятствия
    (100, 600), (120, 600), (140, 600), (160, 600), (180, 600), (200, 600),
    (220, 600), (240, 600), (260, 600), (280, 600), (300, 600),
    # Добавляем вертикальные препятствия
    (100, 460), (100, 480), (100, 500), (100, 520), (100, 540),
    (100, 560), (100, 580),
    # 2

    # 3
    # Добавляем горизонтальные препятствия
    (680, 600), (700, 600), (720, 600), (740, 600), (760, 600), (780, 600),
    (800, 600), (820, 600), (840, 600), (860, 600),
    # Добавляем вертикальные препятствия
    (880, 460), (880, 480), (880, 500), (880, 520), (880, 540), (880, 560),
    (880, 580), (880, 600),
    # 3

    # кубики 23
    (440, 600), (460, 600), (520, 600), (540, 600),

    # кубики 34
    (880, 400), (880, 360), (880, 340), (880, 300),

    # 4
    # Добавляем горизонтальные препятствия
    (880, 240), (880, 220), (880, 200), (880, 180), (880, 160),
    (880, 140),(880, 120), (880, 100),
    # Добавляем вертикальные препятствия
    (680, 100), (700, 100), (720, 100), (740, 100), (760, 100), (780, 100), (800, 100),
    (820, 100), (840, 100), (860, 100),
    # 4

    # кубики 45
    (540, 100), (520, 100), (460, 100), (440, 100),

    # куст 1
    (260, 160,), (280, 180,), (300, 200,), (320, 220,),

    # куст 2
    (320, 480), (300, 500), (280, 520), (260, 540),

    # куст 3
    (720, 160), (700, 180), (680, 200), (660, 220),

    # куст 4
    (660, 480), (680, 500), (700, 520), (720, 540),

    # середина 1
    (560, 300), (560, 320), (560, 380), (560, 400),

    # середина 2
    (420, 300), (420, 320), (420, 380), (420, 400),

    # середина 3
    (460, 280), (480, 280), (500, 280), (520, 280),

    # середина 4
    (460, 420), (480, 420), (500, 420), (520, 420),


    # 12
    (220, 320), (240, 320),
    (220, 340), (240, 340),
    (220, 360), (240, 360),
    (220, 380), (240, 380),

    # 23
    (740, 320), (760, 320),
    (740, 340), (760, 340),
    (740, 360), (760, 360),
    (740, 380), (760, 380),


]

passable_obstacles = [
    # кубики 12
    (100, 260), (100, 280), (100, 320), (100, 380), (100, 420), (100, 440),

    # кубики 23
    (320, 600), (340, 600), (360, 600), (380, 600), (400, 600), (420, 600),
    (480, 600), (500, 600), (560, 600), (580, 600), (600, 600), (620, 600),
    (640, 600), (660, 600),

    # кубики 34
    (880, 440), (880, 420), (880, 380), (880, 320), (880, 280), (880, 260),

    # кубики 45
    (320, 100), (340, 100), (360, 100), (380, 100), (400, 100), (420, 100),
    (480, 100), (500, 100), (560, 100), (580, 100), (600, 100), (620, 100), (640, 100), (660, 100),

    # куст 1
    (180, 160), (200, 160,), (220, 160,), (240, 160,), # x
    (180, 180), (200, 180,), (220, 180,), (240, 180,), (260, 180,),
    (180, 200), (200, 200,), (220, 200,), (240, 200,), (260, 200,), (280, 200,),
    (180, 220), (200, 220,), (220, 220,), (240, 220,), (260, 220,), (280, 220,), (300, 220,),

    # куст 2
    (180, 540), (200, 540), (220, 540), (240, 540),
    (180, 520), (200, 520), (220, 520), (240, 520), (260, 520),
    (180, 500), (200, 500), (220, 500), (240, 500), (260, 500), (280, 500),
    (180, 480), (200, 480), (220, 480), (240, 480), (260, 480), (280, 480), (300, 480),

    # куст 3
    (740, 160), (760, 160), (780, 160), (800, 160),
    (720, 180), (740, 180), (760, 180), (780, 180), (800, 180),
    (700, 200), (720, 200), (740, 200), (760, 200), (780, 200), (800, 200),
    (680, 220), (700, 220), (720, 220), (740, 220), (760, 220), (780, 220), (800, 220),

    # куст 4
    (680, 480), (700, 480), (720, 480), (740, 480), (760, 480), (780, 480), (800, 480),
    (700, 500), (720, 500), (740, 500), (760, 500), (780, 500), (800, 500),
    (720, 520), (740, 520), (760, 520), (780, 520), (800, 520),
    (740, 540), (760, 540), (780, 540), (800, 540),


    # препятствия в середине
    (440, 300), (460, 300), (480, 300), (500, 300), (520, 300), (540, 300),
    (440, 320), (460, 320), (480, 320), (500, 320), (520, 320), (540, 320),
    (440, 340), (460, 340), (480, 340), (500, 340), (520, 340), (540, 340),
    (440, 360), (460, 360), (480, 360), (500, 360), (520, 360), (540, 360),
    (440, 380), (460, 380), (480, 380), (500, 380), (520, 380), (540, 380),
    (440, 400), (460, 400), (480, 400), (500, 400), (520, 400), (540, 400),


]

# FPS контроллер
clock = pygame.time.Clock()
snake_speed = 4

# Начальная позиция змейки
snake_position = [160, 440]
# Тело змейки выровнено вдоль оси X
snake_body = [[160, 440], [140, 440], [120, 440]]

# Вторая змейка
snake2_position = [800, 260]
snake2_body = [[800, 260], [780, 260], [760, 260]]

# Размер блока змейки
block_size = 40
block_size2 = 20

# Загрузка аудиофайлов
pygame.mixer.init()  # Инициализируем микшер звука
eat_sound = pygame.mixer.Sound('./sounds/food__eaten2.mp3')
death_sound = pygame.mixer.Sound('./sounds/death__sound2.mp3')
background_tracks = [
    pygame.mixer.Sound("./sounds/snake__whistle2.mp3"),
    pygame.mixer.Sound("./sounds/leaves__rustling2.mp3"),
    pygame.mixer.Sound("./sounds/cricket__sound2.mp3")
]

def play_random_track():
    track = random.choice(background_tracks)
    track.play()

def generate_food_position():
    while True:
        # Генерация новой позиции для еды
        food_x = random.randrange(offset_x + block_size, offset_x + game_area_width - block_size, block_size)
        food_y = random.randrange(offset_y + block_size, offset_y + game_area_height - block_size, block_size)
        food_position = [food_x, food_y]

        # Проверка, что еда не появляется внутри препятствий
        if not any(food_position == list(obstacle) for obstacle in deadly_obstacles):
            return food_position  # Возвращаем позицию, если она безопасна


# Используем функцию для инициализации позиции еды и когда еда съедена
food_position = generate_food_position()
food_spawn = True

# Направление движения змеек
direction = 'RIGHT'
change_to = direction

direction2 = 'LEFT'
change_to2 = direction2

# Загрузка и масштабирование изображений
background_image = pygame.image.load('./images/111.jpg').convert()
background_image = pygame.transform.scale(background_image, (screen_width, screen_height))
snake_head_img = pygame.image.load('images/head_player1.png')
snake_body_img = pygame.image.load('images/body_player1.png')
snake_head_img_2 = pygame.image.load('images/head_player2.png')
snake_body_img_2 = pygame.image.load('images/body_player2.png')
food_img = pygame.image.load('images/food_snake.png').convert_alpha()  # .convert_alpha() для поддержки прозрачности
food_img = pygame.transform.scale(food_img, (20, 20))
fence_img = pygame.image.load('images/fence1.jpg')
fence_size = fence_img.get_width()
obstacle_image = pygame.image.load('images/obstacle.png')
passable_obstacle_image = pygame.image.load('images/passable_obstacle2.png')
background_image2 = pygame.image.load('./images/backss.jpg')
background_image2 = pygame.transform.scale(background_image2, (screen_width, screen_height))

def draw_text(text, font, color, surface, x, y):
    textobj = font.render(text, True, color)
    textrect = textobj.get_rect(center=(x, y))
    surface.blit(textobj, textrect)

def game_preview():
    for i in range(3, 0, -1):  # Обратный отсчёт от 3 до 1
        screen.blit(background_image2, (0, 0))  # Повторно отображаем фоновое изображение
        countdown_text = f"Игра начнется через: {i}"  # Текст с обратным отсчётом
        draw_text(countdown_text, font2, white, screen, screen_width // 2, screen_height // 2 - 50)  # Отрисовка текста над счётчиком
        pygame.display.update()  # Обновляем отображение на экране

        # Обработка событий (например, закрытия окна) во время обратного отсчёта
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        pygame.time.wait(1000)  # Ждём одну секунду перед следующим шагом обратного отсчёта


def game():
    running = True
    while running:
        global change_to, direction, snake_position, snake_body, food_position, food_spawn, change_to2, direction2, snake2_position, snake2_body
        global head_collision_detected
        head_collision_detected = False
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                # Управление первой змейкой
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_UP:
                        change_to2 = 'UP'
                    elif event.key == pygame.K_DOWN:
                        change_to2 = 'DOWN'
                    elif event.key == pygame.K_LEFT:
                        change_to2 = 'LEFT'
                    elif event.key == pygame.K_RIGHT:
                        change_to2 = 'RIGHT'
                    # Управление второй змейкой
                    elif event.key == pygame.K_w:
                        change_to = 'UP'
                    elif event.key == pygame.K_s:
                        change_to = 'DOWN'
                    elif event.key == pygame.K_a:
                        change_to = 'LEFT'
                    elif event.key == pygame.K_d:
                        change_to = 'RIGHT'

            def get_rotated_image(direction, al_img):

                if direction == 'UP':
                    rotated_image = pygame.transform.rotate(al_img, 0)
                elif direction == 'DOWN':
                    rotated_image = pygame.transform.rotate(al_img, 180)
                elif direction == 'LEFT':
                    rotated_image = pygame.transform.rotate(al_img, 90)
                elif direction == 'RIGHT':
                    rotated_image = pygame.transform.rotate(al_img, -90)
                return rotated_image

            # Отрисовка фона
            screen.blit(background_image, (0, 0))

            # Ограничение изменения направления на противоположное
            if change_to == 'UP' and direction != 'DOWN':
                direction = 'UP'
            elif change_to == 'DOWN' and direction != 'UP':
                direction = 'DOWN'
            elif change_to == 'LEFT' and direction != 'RIGHT':
                direction = 'LEFT'
            elif change_to == 'RIGHT' and direction != 'LEFT':
                direction = 'RIGHT'

            if change_to2 == 'UP' and direction2 != 'DOWN':
                direction2 = 'UP'
            elif change_to2 == 'DOWN' and direction2 != 'UP':
                direction2 = 'DOWN'
            elif change_to2 == 'LEFT' and direction2 != 'RIGHT':
                direction2 = 'LEFT'
            elif change_to2 == 'RIGHT' and direction2 != 'LEFT':
                direction2 = 'RIGHT'

            # Движение змеек
            if direction == 'UP':
                snake_position[1] -= 20
            elif direction == 'DOWN':
                snake_position[1] += 20
            elif direction == 'LEFT':
                snake_position[0] -= 20
            elif direction == 'RIGHT':
                snake_position[0] += 20

            if direction2 == 'UP':
                snake2_position[1] -= 20
            elif direction2 == 'DOWN':
                snake2_position[1] += 20
            elif direction2 == 'LEFT':
                snake2_position[0] -= 20
            elif direction2 == 'RIGHT':
                snake2_position[0] += 20
            if not pygame.mixer.get_busy():  # Проверяем, не проигрывается ли уже какой-либо трек
                play_random_track()
            # Логика роста змеек и еды
            snake_body.insert(0, list(snake_position))
            snake2_body.insert(0, list(snake2_position))
            food_eaten = False

            if snake_position == food_position:
                food_spawn = False
                food_eaten = True
            else:
                snake_body.pop()

            if snake2_position == food_position:
                food_spawn = False
                food_eaten = True
            else:
                snake2_body.pop()

            if not food_spawn:
                food_position = generate_food_position()  # Генерация новой позиции для еды, если старая была съедена
                food_spawn = True
                eat_sound.play()

            # Отрисовка еды
            screen.blit(food_img, (food_position[0], food_position[1]))

            # отрисовка первого игрока
            for pos in snake_body:
                if pos == snake_body[0]:  # Голова змеи
                    # При отрисовке головы змейки
                    rotated_head_img = get_rotated_image(direction, snake_head_img)
                    screen.blit(rotated_head_img, (snake_body[0][0], snake_body[0][1]))
                else:  # Тело змеи первого игрока
                    # Для тела используем другое изображение и его же поворачиваем
                    rotated_body_img = get_rotated_image(direction, snake_body_img)
                    screen.blit(rotated_body_img, (pos[0], pos[1]))
            # отрисовка второго игрока
            for pos in snake2_body:
                if pos == snake2_body[0]:  # Голова змеи второго игрока
                    # При отрисовке головы змейки
                    rotated_head_img2 = get_rotated_image(direction2, snake_head_img_2)
                    screen.blit(rotated_head_img2, (snake2_body[0][0], snake2_body[0][1]))
                else:  # Тело змеи второго игрока
                    # Для тела используем другое изображение и его же поворачиваем
                    rotated_body_img2 = get_rotated_image(direction2, snake_body_img_2)
                    screen.blit(rotated_body_img2, (pos[0], pos[1]))

            # Проверка столкновения головы одной змейки с телом другой
            for block in snake_body[1:2]:
                if snake2_position == block:
                    handle_death("head__collision", len(snake_body), len(snake2_body))
            # Проверка столкновения головы одной змейки с телом другой
            for block in snake_body[1:]:
                if snake2_position == block:
                    handle_death("death__body1", len(snake_body), len(snake2_body))
            for block in snake2_body[1:]:
                if snake_position == block:
                    handle_death("death__body2", len(snake_body), len(snake2_body))

            head_pos = snake_body[0]
            head_pos2 = snake2_body[0]

            # Сначала проверяем, не столкнулись ли обе змейки с забором одновременно
            if (head_pos[0] < offset_x + (block_size // 2) or head_pos[0] >= (
                    offset_x + game_area_width - (block_size // 2)) or head_pos[1] < offset_y + (block_size // 2) or
                head_pos[1] >= (offset_y + game_area_height - (block_size // 2))) and \
                    (head_pos2[0] < offset_x + (block_size // 2) or head_pos2[0] >= (
                            offset_x + game_area_width - (block_size // 2)) or head_pos2[1] < offset_y + (
                             block_size // 2) or head_pos2[1] >= (offset_y + game_area_height - (block_size // 2))):
                handle_death("death__fence_both", len(snake_body), len(snake2_body))

            # Теперь проверяем столкновение каждой змейки индивидуально
            else:
                if head_pos[0] < offset_x + (block_size // 2) or head_pos[0] >= (
                        offset_x + game_area_width - (block_size // 2)) or head_pos[1] < offset_y + (block_size // 2) or \
                        head_pos[1] >= (offset_y + game_area_height - (block_size // 2)):
                    handle_death("death__fence1", len(snake_body), len(snake2_body))

                if head_pos2[0] < offset_x + (block_size // 2) or head_pos2[0] >= (
                        offset_x + game_area_width - (block_size // 2)) or head_pos2[1] < offset_y + (
                        block_size // 2) or head_pos2[1] >= (offset_y + game_area_height - (block_size // 2)):
                    handle_death("death__fence2", len(snake_body), len(snake2_body))

            def draw_obstacles(screen, obstacles, image):
                for obstacle in obstacles:
                    screen.blit(image, obstacle)
            draw_obstacles(screen, deadly_obstacles, obstacle_image)
            draw_obstacles(screen, passable_obstacles, passable_obstacle_image)
            def check_collision_with_obstacles(snake_head, obstacles, block_size2):
                snake_rect = pygame.Rect(snake_head[0], snake_head[1], block_size2, block_size2)
                for obstacle in obstacles:
                    obstacle_rect = pygame.Rect(obstacle[0], obstacle[1], block_size2, block_size2)
                    if snake_rect.colliderect(obstacle_rect):
                        return True
                return False

            # Проверяем одновременное столкновение обеих змеек с препятствиями
            if check_collision_with_obstacles(snake_body[0], deadly_obstacles, block_size2) and check_collision_with_obstacles(snake2_body[0],
                deadly_obstacles, block_size2):
                handle_death("death__collision_both", len(snake_body), len(snake2_body))

            # Проверяем столкновение первой змейки с препятствиями
            elif check_collision_with_obstacles(snake_body[0], deadly_obstacles, block_size2):
                handle_death("death__collision1", len(snake_body), len(snake2_body))

            # Проверяем столкновение второй змейки с препятствиями
            elif check_collision_with_obstacles(snake2_body[0], deadly_obstacles, block_size2):
                handle_death("death__collision2", len(snake_body), len(snake2_body))

            # Рисуем забор вокруг игровой зоны
            for x in range(offset_x, offset_x + game_area_width, fence_size):
                screen.blit(fence_img, (x, offset_y))  # Верхняя граница
                screen.blit(fence_img, (x, offset_y + game_area_height - fence_size))  # Нижняя граница

            for y in range(offset_y, offset_y + game_area_height, fence_size):
                screen.blit(fence_img, (offset_x, y))  # Левая граница
                screen.blit(fence_img, (offset_x + game_area_width - fence_size, y))  # Правая граница'''


            def show_score():
                score_text = font.render('P1 Score: ' + str(len(snake_body) - 3), True, blue)  # Синий цвет
                score2_text = font.render('P2 Score: ' + str(len(snake2_body) - 3), True, yellow)  # Желтый цвет
                screen.blit(score_text, [0, 0])
                screen.blit(score2_text, [screen_width - 150, 0])

            # Вызовите функцию show_score() в основном игровом цикле
            show_score()

            # Обновление экрана
            pygame.display.flip()

            # Контроль скорости змеек
            clock.tick(snake_speed)

        draw_text('The game begins!', font2, white, screen, screen_width // 2, screen_height // 2)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        pygame.display.update()

def handle_death(death_type, snake_length, snake2_length):
    death_sound.play()
    pygame.time.delay(500)
    result = end_game_menu(death_type, snake_length - 3, snake2_length - 3)
    if result == "restart":
        restart_game()
    else:
        pygame.quit()
        sys.exit()

def end_game_menu(reason, player1_score, player2_score):

    # Определение победителя или ничьи
    if reason == "head__collision":
        if player1_score > player2_score:
            winner_text = "P1 выиграл по очкам"
        elif player2_score > player1_score:
            winner_text = "P2 выиграл по очкам"
        else:
            winner_text = "Ничья"
    elif reason == "death__body1":
        winner_text = "P1 выиграл"
    elif reason == "death__body2":
        winner_text = "P2 выиграл"

    if reason == "death__fence_both":
        if player1_score > player2_score:
            winner_text = "P1 выиграл по очкам"
        elif player2_score > player1_score:
            winner_text = "P2 выиграл по очкам"
        else:
            winner_text = "Ничья"
    elif reason == "death__fence1":
        winner_text = "P2 выиграл"
    elif reason == "death__fence2":
        winner_text = "P1 выиграл"

    if reason == "death__collision_both":
        if player1_score > player2_score:
            winner_text = "P1 выиграл по очкам"
        elif player2_score > player1_score:
            winner_text = "P2 выиграл по очкам"
        else:
            winner_text = "Ничья"
    elif reason == "death__collision1":
        winner_text = "P2 выиграл"
    elif reason == "death__collision2":
        winner_text = "P1 выиграл"

    # Вывод информации на экран
    while True:
        screen.blit(background_image2, (0, 0))
        draw_text("Игра окончена", font2, red, screen, screen_width // 2, screen_height // 2 - 100)
        draw_text(winner_text, font, white, screen, screen_width // 2, screen_height // 2)
        draw_text("P1 счет: " + str(player1_score), font2, blue, screen, screen_width // 2, screen_height // 2 + 50)
        draw_text("P2 счет: " + str(player2_score), font2, yellow, screen, screen_width // 2, screen_height // 2 + 100)
        draw_text("Нажмите 'R' для перезапуска или 'Q' для выхода", font2, white, screen, screen_width // 2, screen_height // 2 + 150)
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    return "restart"
                elif event.key == pygame.K_q:
                    pygame.quit()
                    sys.exit()

def restart_game():
    global snake_position, snake_body, snake2_position, snake2_body
    global direction, change_to, direction2, change_to2, game_over

    # Начальная позиция и тело первой змейки
    snake_position = [160, 440]
    snake_body = [[160, 440], [140, 440], [120, 440]]

    # Начальная позиция и тело второй змейки
    snake2_position = [800, 260]
    snake2_body = [[800, 260], [820, 260], [840, 260]]

    # Установка начальных направлений для змеек
    direction = 'RIGHT'
    change_to = direction
    direction2 = 'LEFT'
    change_to2 = direction2

    game_over = False  # Сбросить флаг окончания игры


selected_item = 0
def main_menu():
    global selected_item
    menu_items = ['Начать игру', 'Выйти']
    menu_start_y = (screen_height // 2) - (len(menu_items) * 60 // 2)

    while True:
        screen.blit(background_image2, (0, 0))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    selected_item = (selected_item - 1) % len(menu_items)
                elif event.key == pygame.K_DOWN:
                    selected_item = (selected_item + 1) % len(menu_items)
                elif event.key == pygame.K_RETURN:
                    if selected_item == 0:
                        game_preview()  # Показать предпросмотр игры
                        game()  # Запустить игру
                        return  # Возвращаемся к меню после завершения игры
                    elif selected_item == 1:
                        pygame.quit()
                        sys.exit()

        for i, item in enumerate(menu_items):
            if i == selected_item:
                draw_text(item, font2, red, screen, screen_width // 2, menu_start_y + i * 60)
            else:
                draw_text(item, font2, white, screen, screen_width // 2, menu_start_y + i * 60)

        pygame.display.update()

main_menu()